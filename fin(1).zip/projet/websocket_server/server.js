// websocket_server/server.js

const WebSocket = require('ws');

// Définissez le port de votre serveur WebSocket.
// Choisissez un port non utilisé, par exemple 8080 ou 8081.
// Ce port doit être différent du port de votre serveur web (ex: 80 pour Apache).
const WS_PORT = 8080;
const wss = new WebSocket.Server({ port: WS_PORT });

console.log(`Serveur WebSocket démarré sur le port ${WS_PORT}`);

// Structure pour stocker les clients par ID de conversation.
// Chaque clé est un conversation_id, et la valeur est un Set de WebSockets.
const conversations = new Map(); // Map<conversation_id, Set<WebSocket>>

wss.on('connection', function connection(ws) {
    console.log('Nouvelle connexion WebSocket établie.');

    // Chaque connexion est unique et sera associée à une ou plusieurs conversations
    // On n'assigne pas de conversation ici, on attend un message 'join_conversation'.

    ws.on('message', function incoming(message) {
        try {
            const parsedMessage = JSON.parse(message);
            console.log('Message reçu du client:', parsedMessage);

            // Gérer les différents types de messages reçus du client
            if (parsedMessage.type === 'join_conversation' && parsedMessage.conversation_id) {
                const convId = parsedMessage.conversation_id;
                if (!conversations.has(convId)) {
                    conversations.set(convId, new Set());
                }
                conversations.get(convId).add(ws);
                console.log(`Client abonné à la conversation ${convId}.`);

                // Envoyer au client une confirmation ou l'état initial si nécessaire
                ws.send(JSON.stringify({ type: 'joined', conversation_id: convId }));

            } else if (parsedMessage.type === 'chat_message' && parsedMessage.conversation_id) {
                // C'est un message de chat à diffuser
                const convId = parsedMessage.conversation_id;

                // On ne devrait pas insérer en DB ici. PHP est le responsable de la DB.
                // Ce serveur WebSocket est juste pour la diffusion.

                // Diffuser le message aux autres clients de la même conversation
                if (conversations.has(convId)) {
                    conversations.get(convId).forEach(function(clientWs) {
                        // Ne pas renvoyer le message à l'expéditeur lui-même,
                        // car son navigateur l'a déjà affiché immédiatement après l'envoi.
                        // Si vous voulez gérer les accusés de réception, vous pourriez l'envoyer aussi à l'expéditeur.
                        if (clientWs !== ws && clientWs.readyState === WebSocket.OPEN) {
                            clientWs.send(JSON.stringify(parsedMessage));
                        }
                    });
                    console.log(`Message diffusé dans la conversation ${convId}.`);
                } else {
                    console.warn(`Conversation ${convId} non trouvée pour la diffusion.`);
                }
            } else {
                console.warn('Type de message inconnu ou données manquantes:', parsedMessage);
            }

        } catch (e) {
            console.error('Erreur de parsing JSON ou message non valide:', message.toString(), e);
            ws.send(JSON.stringify({ type: 'error', message: 'Format de message invalide.' }));
        }
    });

    ws.on('close', function close() {
        // Quand un client se déconnecte, le retirer de toutes les conversations où il était abonné
        conversations.forEach((clientsSet, convId) => {
            if (clientsSet.has(ws)) {
                clientsSet.delete(ws);
                if (clientsSet.size === 0) {
                    conversations.delete(convId); // Nettoyage si la conversation est vide
                }
            }
        });
        console.log('Connexion WebSocket fermée.');
    });

    ws.on('error', function error(err) {
        console.error('Erreur WebSocket:', err);
    });
});